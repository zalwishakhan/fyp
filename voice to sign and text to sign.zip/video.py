import cv2
from cvzone.HandTrackingModule import HandDetector
from cvzone.ClassificationModule import Classifier
import numpy as np
import math
from tkinter import *
import tkinter as tk
import threading

# Home page navigation
def home_page():
    root.destroy()
    import start  # Adjust if `start` is not a valid module

# Start video processing in a separate thread
def start_video_thread():
    threading.Thread(target=startVideo).start()

# Video processing logic
def startVideo():
    print("Initializing camera...")
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not access the camera.")
        return

    detector = HandDetector(maxHands=1)
    classifier = Classifier(
        "C:/Users/ADMIN/Desktop/detc/Model/keras_model.h5",
        "C:/Users/ADMIN/Desktop/detc/Model/labels.txt"
    )

    offset = 20
    imgSize = 300
    labels = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U",
              "V", "W", "X", "Y", "Z"]
    wait = 0

    while True:
        success, img = cap.read()
        if not success:
            print("Error: Unable to capture video.")
            break

        imgOutput = img.copy()
        hands, img = detector.findHands(img)

        if hands:
            hand = hands[0]
            x, y, w, h = hand['bbox']

            imgWhite = np.ones((imgSize, imgSize, 3), np.uint8) * 255
            try:
                imgCrop = img[y - offset:y + h + offset, x - offset:x + w + offset]
                aspectRatio = h / w

                if aspectRatio > 1:
                    k = imgSize / h
                    wCal = math.ceil(k * w)
                    imgResize = cv2.resize(imgCrop, (wCal, imgSize))
                    wGap = math.ceil((imgSize - wCal) / 2)
                    imgWhite[:, wGap:wCal + wGap] = imgResize
                else:
                    k = imgSize / w
                    hCal = math.ceil(k * h)
                    imgResize = cv2.resize(imgCrop, (imgSize, hCal))
                    hGap = math.ceil((imgSize - hCal) / 2)
                    imgWhite[hGap:hCal + hGap, :] = imgResize

                prediction, index = classifier.getPrediction(imgWhite, draw=False)

                wait += 1
                if wait == 40:
                    print("Predicted letter:", labels[index])
                    T.insert(tk.END, labels[index] + " ")
                    wait = 0

                cv2.rectangle(imgOutput, (x - offset, y - offset - 50),
                              (x - offset + 90, y - offset - 50 + 50), (255, 0, 255), cv2.FILLED)
                cv2.putText(imgOutput, labels[index], (x, y - 26),
                            cv2.FONT_HERSHEY_COMPLEX, 1.7, (255, 255, 255), 2)
                cv2.rectangle(imgOutput, (x - offset, y - offset),
                              (x + w + offset, y + h + offset), (255, 0, 255), 4)
            except Exception as e:
                print(f"Error processing hand region: {e}")

        cv2.imshow("Image", imgOutput)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Tkinter GUI setup
root = Tk()
root.geometry("300x300")
root.title("SIGN-LANGUAGE-CONVERTER")
root.state('zoomed')

Home = Button(root, height=2, width=20, text="Home", command=lambda: home_page())
Home.pack()

l1 = Label(root, text="To print Alphabets \n one-by-one click button below", font='Helvetica 20 bold')
l1.place(relx=0.50, rely=0.10, anchor=N)

T = Text(root, height=30, width=70)
T.pack(side=BOTTOM)

Display = Button(root, height=2, width=20, text="Start Video", command=start_video_thread)
Display.place(relx=0.50, rely=0.25, anchor=N)

mainloop()
