import tkinter as tk
from datetime import time
import time
from tkinter import *
from tkinter import font
import speech_recognition as sr
import pyttsx3


def home_page():
    frame.destroy()
    import start


# Top level window
frame = tk.Tk()
frame.title("TEXT-TO-SIGN")
frame.geometry('400x200')
frame.state('zoomed')

Home = Button(frame, height=2,
              width=20,
              text="Home",
              command=lambda: home_page())
Home.pack()

l1 = Label(frame, text="To Display ASL write below \n and click button below", font='Helvetica 20 bold')
l1.pack()


# Function for getting Input
# from textbox and printing it
# at label widget

def printInput():
    inp = inputtxt.get(1.0, "end-1c")
    inp = inp.lower()
    for i in inp:
        if i == 'a':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/A.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'b':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/B.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'c':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/C.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'd':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/D.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img  # Prevent garbage collection
            lbl.update()
            time.sleep(1)

        elif i == 'e':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/E.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'f':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/F.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'g':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/G.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'h':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/H.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'i':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/I.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'j':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/J.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'k':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/K.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'l':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/L.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'm':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/M.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'n':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/N.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'o':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/O.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'p':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/P.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'q':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/Q.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'r':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/R.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 's':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/S.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 't':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/T.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'u':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/U.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'v':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/V.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'w':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/W.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'x':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/X.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'y':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/Y.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'z':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/Z.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)

# TextBox Creation
inputtxt = tk.Text(frame,
                   height=10,
                   width=40)

inputtxt.pack()


#########################################################################################################
def voice_text():
    r = sr.Recognizer()

    def SpeakText(command):
        engine = pyttsx3.init()
        engine.say(command)
        engine.runAndWait()

    with sr.Microphone() as source2:
        r.adjust_for_ambient_noise(source2, duration=0.2)
        audio2 = r.listen(source2)
        MyText = r.recognize_google(audio2)
        MyText = MyText.lower()
        print(MyText)
    l2 = Label(frame, text=MyText,
               font='Helvetica 20 bold')
    l2.pack()


    for i in MyText:
        if i == 'a':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/A.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'b':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/B.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            time.sleep(1)
        elif i == 'c':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/C.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'd':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/D.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'e':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/E.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'f':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/F.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'g':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/G.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'h':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/H.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'i':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/I.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'j':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/J.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'k':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/K.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'l':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/L.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'm':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/M.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'n':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/N.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'o':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/O.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'p':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/P.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'q':
            img = PhotoImage(file="VoicC:/Users/ADMIN/Desktop/detce/Q.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'r':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/R.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 's':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/S.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 't':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/T.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'u':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/U.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'v':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/V.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'w':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/W.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'x':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/X.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'y':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/Y.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)
        elif i == 'z':
            img = PhotoImage(file="C:/Users/ADMIN/Desktop/detc/Z.png").subsample(2, 2)
            lbl.configure(image=img)
            lbl.image = img
            lbl.update()
            time.sleep(1)

    l2.after(100, l2.destroy())

#################################################################################################################

buttonFont = font.Font(family='Helvetica', size=16, weight='bold')
# Button Creation

voiceButton = tk.Button(frame,
                        text="Voice",
                        command=voice_text, font=buttonFont).place(x=1050,y=150)

printButton = tk.Button(frame,
                        text="Show",
                        command=printInput, font=buttonFont)
printButton.pack()

# Label Creation
lbl = tk.Label(frame, text="")
lbl.pack()
frame.mainloop()